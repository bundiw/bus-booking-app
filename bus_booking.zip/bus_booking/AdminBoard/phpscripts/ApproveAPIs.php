<?php 

require_once '../../DbConnect.php';
$response = array();
$status = $_POST["status"];
$book_id = $_POST["book_id"];
$admin = $_POST["token"];
$ticket_no = $_POST["ticket"];
 
if (isset($admin)) {
  
    $stmt = $conn->prepare("UPDATE `book_bus` SET `ticket_no` = ?, `book_status` = ?, `admin_no` = ? WHERE `book_id`=? ");
    $stmt->bind_param("ssss",$ticket_no,$status, $admin, $book_id);
    
    if ($stmt->execute()) {

        $stmt->close();
        
        $response['error'] = false; 
        $response['message'] = 'Bus Book sucessfully'; 
       
    } 
    
    else{
        $response['error'] = true; 
        $response['message'] = 'An error has occured, report to the developer for bug fix!';
    }
}else{
    $response['error'] = true; 
    $response['message'] = 'Access denied, No permission';
}
echo json_encode($response);
