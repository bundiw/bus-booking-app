<?php

require_once '../../DbConnect.php';
$response = array();


//SELECT `bus_id`, `user_id`, `plate_registration`, `bus_condition`, `bus_capacity` FROM `buses` WHERE 1
// $_POST["token"]=15;
// $_POST["action"] ="analysis";
$token = $_POST["token"];

// $_POST["action"]="approve";

if ($token == "") {
    $response['error'] = true; 
    $response['message'] = 'Unauthorised Access!';

}else{
    $menu = $_POST["action"];

    if ($menu == "analysis") {
        $stmt = $conn->prepare("SELECT  `depart_from`, `destination`, SUM(`ticket_amount`) as amount, COUNT(`depart_from`) as numb FROM `book_bus` GROUP BY `depart_from`,`destination`");
       
        
        $stmt->execute();
        $stmt->bind_result($from, $to, $sum, $count);
        $res = $stmt->get_result();
        if($res->num_rows > 0){
            while ($rep = $res->fetch_assoc()){
           
               $report[] = $rep ;
               
            }
            
            $stmt->close();
            $response['error'] = false; 
            $response['message'] = 'Summary fetched sucessfully'; 
            $response['analysis'] = $report;
        }else{
            $stmt->close();
            $response['error'] = true; 
            $response['message'] = 'No Data Available!'; 

        }
    

    }else if ($menu == "routes") {
     
         $registration = $_POST["registration"];
         $from = $_POST["from"];
         $destination = $_POST["destination"];
         $comfort = $_POST["comfort"];
         $day = $_POST["day"];
         $time = $_POST["time"];
         $cost = $_POST["cost"];

         //INSERT INTO `routes`(`route_id`, `plate_registration`, `depart_from`, `destination`, `travel_date`, `travel_time`, `travel_cost`) VALUES 
        $stmt = $conn->prepare("INSERT INTO `routes`( `plate_registration`, `depart_from`, `destination`, `bus_comfort`, `travel_date`, `travel_time`, `travel_cost`) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssss",$registration, $from, $destination, $comfort, $day, $time, $cost);
        
        if ($stmt->execute()) {

            $stmt = $conn->prepare("SELECT `route_id`, `plate_registration`, `travel_date`, `travel_time`, `travel_cost` FROM `routes` WHERE 1"); 
            
            $stmt->execute();
            $stmt->bind_result($id, $registration, $date, $time, $cost);
            $res = $stmt->get_result();
            while ($route = $res->fetch_assoc()){
               
               $routes[] = $route ;
            }
                        
            
            $stmt->close();
            
            $response['error'] = false; 
            $response['message'] = 'Route Added sucessfully'; 
            $response['routes'] = $routes;
        }
        
        else{
            $response['error'] = true; 
            $response['message'] = 'Empty/Duplicate Entries are not allowed!';
        }

    }else if ($menu == "approve") {
      //SELECT `book_id`, `depart_from`, `destination`, `capacity`, `bus_comfort`,
      //`book_date`, `book_time`, `book_status`, `ticket_no` FROM `book_bus` WHERE `book_status` = null
      //calculate the next ticket
        $status = "pending";

        $stmt = $conn->prepare("SELECT `book_id`,`user_email`,`ticket_amount`, `depart_from`, `destination`, `capacity`, `plate_registration`, `bus_comfort`, `book_date`, `book_time` FROM `book_bus` WHERE `book_status` = ?");
        $stmt->bind_param("s",$status);
        $stmt->execute();
        
        $stmt->bind_result($id,$email,$cost, $from, $to, $capacity, $registration, $comfort, $date, $time);
       $res = $stmt->get_result();
        
        if($res->num_rows > 0){
            while($book = $res->fetch_assoc()){
               // $stmt->close();

                
                $books[] =  $book;

                
            }
            $stmt->close();
            //just for testing purpose
            // $active ="active";
            // $tickets[] =0;
            $stmt = $conn->prepare("SELECT COUNT(`plate_registration`) as ticket FROM `book_bus` GROUP BY `book_date`,`book_time`");
            $stmt->bind_param("s",$active);
            $stmt->execute();
            $stmt->bind_result($ticket);
            $res = $stmt->get_result();
            while($row = $res->fetch_assoc()){
                               
                $tickets[] = $row ;

                
            }

            $stmt->close();
        
            $response['error'] = false; 
            $response['message'] = 'Bookings Added sucessfully'; 
            $response['books'] = $books;
            $response['tickets'] =$tickets;
            

            


        }else{
            $response['error'] = true; 
            $response['message'] = 'No data Available'; 
           
        }

       
    }else{
        $registration = $_POST["registration"];
        $condition = $_POST["comfort"];
        $capacity = $_POST["capacity"];
       
        $stmt = $conn->prepare("INSERT INTO `buses`(`user_id`, `plate_registration`, `bus_condition`, `bus_capacity`) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss",$token, $registration, $condition, $capacity);
        
        if ($stmt->execute()) {

            $stmt = $conn->prepare("SELECT `bus_id`,`plate_registration`, `bus_condition`, `bus_capacity` FROM `buses` WHERE `plate_registration` = ?"); 
            $stmt->bind_param("s",$registration);
            $stmt->execute();
            $stmt->bind_result($id, $registration, $condition, $capacity);
            $stmt->fetch();
            
            $buses = array(
                'bus_id'=>$id, 
                'registration'=>$registration, 
                'condition'=>$condition, 
                'capacity'=>$capacity
                
            );
            
            $stmt->close();
            
            $response['error'] = false; 
            $response['message'] = 'Bus Added sucessfully'; 
            $response['buses'] = $buses;
        }
        
        else{
            $response['error'] = true; 
            $response['message'] = 'Empty/Duplicate Entries are not allowed!';
        }


    }

}
echo json_encode($response);
