<?php 

require_once '../../DbConnect.php';
$response = array();


$display = $_POST["show"]; 
if ($display == "on") {

    $stmt = $conn->prepare("SELECT `bus_id`, `plate_registration`, `bus_condition`, `bus_capacity` FROM `buses` "); 
    $stmt->execute();
    $stmt->bind_result($id, $registration, $condition, $capacity);
    $res = $stmt->get_result();
    while ($bus = $res->fetch_assoc()){
       
       $buses[] = $bus ;
    }
    
    $stmt->close();
    $response['error'] = false; 
    $response['message'] = 'Buses fetched sucessfully'; 
    $response['buses'] = $buses;
}
echo json_encode($response);
