<?php
require_once '../../DbConnect.php';
$response = array();

$action = $_POST["login"];
if($action == "log action"){
	$email = $_POST['username'];
	$password = md5($_POST['password']); 
	
	$stmt = $conn->prepare("SELECT user_id, username, phone, email, gender FROM users WHERE email = ? AND password = ?");
	$stmt->bind_param("ss",$email, $password);
	
	$stmt->execute();
	
	$stmt->store_result();
	
	if($stmt->num_rows > 0){
		
		$stmt->bind_result($id, $username, $phone, $email, $gender);
		$stmt->fetch();
		
		$user = array(
			'user_id'=>$id, 
			'username'=>$username,
			'phone'=>$phone, 
			'email'=>$email,
			'gender'=>$gender
		);
		
		$response['error'] = false; 
		$response['message'] = 'Login successfull'; 
		$response['user'] = $user; 
	}else{
		$response['error'] = true; 
		$response['message'] = 'Invalid username or password';
	}
				

}else{
	$response['error'] = true; 
	$response['message'] = 'Invalid API Call';
}

echo json_encode($response);
