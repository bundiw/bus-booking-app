$(document).ready(function(){
    var page = localStorage.getItem("page")
    var token = localStorage.getItem("token")

	
	
    if (token == "") {
    	localStorage.setItem("user","")
		localStorage.setItem("token","")
    	$(location).attr("href","./login.html")

    }else{
	  	home();
	  	$("#user").text(localStorage.getItem("user"))


	  	$("a").click(function(){
			page = $(this).attr("href"); 
			page = page.replace("#","")
			localStorage.setItem("page",page)
		   
		   	if (page == "analysis") {
		   		analysis()

		    }else if (page == "routes") {
		    	routes()

		    }else if (page == "approve") {
		    	approve()

		    }else{
	    		home();

		    }
	    

		})
    }

 function analysis(){

 	$.post("phpscripts/MainAPIs.php",{
		 	"token":token,
          	"action":page
		},function(data,status){
			
			                
	        if(status == "success"){
	            //$response['error'] = true; 
	            //$response['message'] = 'Invalid username or password';

	            var response =JSON.parse(data)

	            if(response["error"] == false){
            		var summary=$("#book_summary")
            		summary.empty()

	               var ana = response["analysis"]
	              
	               var counter = 0
	               $.each(ana, function(key,val){
	               	    counter++;

	               		summary.append('<tr><td>'+counter+'</td><td>'+val.depart_from+
	               			'</td><td>'+val.destination+'</td><td>'+val.numb+'</td><td>'+val.amount+'</td></tr>')

	               })
	               summary.prepend("<tr><td>No.</td><td>From</td><td>To</td><td>Trips</td><td>Amount</td></tr>")
	               
	               
	              
	            }else{
	            	var summary=$("#book_summary")
            		summary.empty()
            		summary.prepend("<tr><td>No.</td><td>From</td><td>To</td><td>Trips</td><td>Amount</td></tr>")
	            	alert(response['message'])
	            }

	        }else{
	            alert("Please retry an error has occured")
	        }
	})

 }
    
 function add_route(){
 	//do more staff here
					
   $("#bus_route > input[type = submit]").click(function(e){
  
   	var registration = $("#bus_registration").val()
   	var from = $("#departure_place").val()
   	var destination = $("#destination_place").val()
   	var comfort = $("#bus_comfort").val()
   	var day = $("#departure_day").val()
   	var time = $("#departure_time").val()
   	var cost = $("#trip_cost").val()
	
	var peak_on = $("#is-peak")
	var peak_off = $("#is-not-peak")
	var peak_value =null
	var today = new Date();
	today = today.toISOString()
	today=today.slice(0,10)
	

	//console.log(JSON.stringify($("#is-peak")))
	if(peak_on.prop("checked"))
	{
		
		peak_value = peak_on.val()
		
	}else if(peak_off.prop("checked")){
		peak_value = peak_off.val()
		

	}else{
		peak_value =null
			

	}
	
	if(day < today){
		alert("Date Must be past Current date")
	}else{
		if (peak_value && registration && from && destination && comfort && day && time && cost) {

			if(peak_value === "Off Peak"){
				cost *=0.9
	
			}
			//alert("Test "+cost)
			$.post("phpscripts/MainAPIs.php",{
				"token":token,
				"action":page,
				"registration":registration,
				"from":from,
				"destination":destination,
				"comfort":comfort,
				"day":day,
				"time":time,
				"cost":cost
	
			},function(data,status){
				
				
				if(status == "success"){
					//$response['error'] = true; 
					//$response['message'] = 'Invalid username or password';
					var response =JSON.parse(data)
	
	
					if(response["error"] == false){
					   
					   alert(response["message"])
					   $(":input").val('')
	
					  
					}else{
						alert(response["message"])
					   
					} 
								 
				}else{
					alert("Please retry an error has occured")
				}
	
			})
	
		   }else{
			
			   alert("All field must be filled!")
			
		   }

	}
		
	
    e.preventDefault()
   })
 
 }

function routes(){

	$.post("phpscripts/SubAPIs.php",{
		"show":"on"
		},function(data,status){
			
			                
	        if(status == "success"){
	            //$response['error'] = true; 
	            //$response['message'] = 'Invalid username or password';

	            var response =JSON.parse(data)

	            if(response["error"] == false){
            		var registration=$("#bus_registration")
            		registration.empty()

	               var buses = response["buses"]
	              
	               registration.append("<option value=''>_SELECT BUS_</option>")
	               $.each(buses, function(key,val){
	               	
	               		registration.append('<option value="'+val.plate_registration+'">Registration No.'+val.plate_registration+', Condition '
	               			+val.bus_condition.toUpperCase()+', Seats '+ val.bus_capacity+'</option>')

	               })
	               add_route()
	               
	               
	              
	            }else{
	            	var registration=$("#bus_registration")
            		registration.empty()
            		registration.prepend("<option value=''>_SELECT BUS_</option>")
	            	alert(response['message'])
	            }

	        }else{
	            alert("Please retry an error has occured")
	        }
	})

}   
function approve_action(book_id,ticket){
	//status book_id token
	$.post("phpscripts/ApproveAPIs.php",{
            "token":token,
            "book_id":book_id,
            "status":"ACTIVE",
            "ticket": ticket
            
        },function(data, status){
        	 if(status == "success"){
	            

	            var response =JSON.parse(data)
	            if(response["error"] == false){
	            	alert(response['message'])
	            	
	            }else{
	            	alert(response['message'])

	            }

	        }else{
	            alert("Please retry an error has occured")
	        }


        })

}

function approve(){

	$.post("phpscripts/MainAPIs.php",{
            "token":token,
            "action":page
            
        },function(data,status){
			
			                
	        if(status == "success"){
	            //$response['error'] = true; 
	            //$response['message'] = 'Invalid username or password';

	            var response =JSON.parse(data)

	            if(response["error"] == false){
            		//do staff like populating the table
            		var books = response["books"]
            		var book_no = response["tickets"]
            		//alert(book_no[1]["ticket"])
            		//alert(book_no)
            		var id="td";
            		var approve_tb = $("#approve_book")
            		approve_tb.empty()
            		var counter=0;
            		$.each(books, function(key,val){
            			counter++

//`user_email`,`ticket_amount`,
						approve_tb.append('<tr>'+
											'<td>'+counter+'</td>'+
											'<td>'+val.user_email+'</td>'+
											'<td>'+val.ticket_amount+'</td>'+
											'<td>'+val.depart_from+'</td>'+
											'<td>'+val.destination+'</td>'+
											'<td>'+val.capacity+'</td>'+
											'<td>'+val.bus_comfort+'</td>'+
											'<td id='+(val.book_id)+id+'>'+(parseInt(book_no[--counter]["ticket"])+1)+'</td>'+
											'<td>'+val.book_date+' '+val.book_time+'</td>'+
											'<td>'+'<button id='+val.book_id+'>BOOK</button></td>'+
										'</tr>')
	               	
	               })
            		approve_tb.prepend("<tr> <td>No.</td><td>Email</td><td>Cost</td><td>From</td><td>To</td><td>Capacity</td><td>Comfort Level</td>"+
            			"<td> Next Ticket For Route.</td><td>Date/Time</td><td>Action</td></tr>")
            		$("button").click(function(){
            			var book_id = $(this).attr('id')
            			var book_number =$("#"+book_id+id).text()
            			alert(book_number)
            			approve_action(book_id,parseInt(book_number+1)) ;


            			location.reload();


            		})
	                           		
	               
	              
	            }else{
	            	var approve_tb = $("#approve_book")
            		approve_tb.empty()
            		approve_tb.prepend("<tr> <td>No.</td><td>Email</td><td>Cost</td><td>From</td><td>To</td><td>Capacity</td><td>Comfort Level</td>"+
            			"<td>Next Ticket For Route.</td><td>Date/Time</td><td>Action</td></tr>")
	            	alert(response['message'])
	            }

	        }else{
	            alert("Please retry an error has occured")
	        }
	})

}
function home(){
	
 	$("#add_bus >input[type=submit]").click(function(){

        //var text = $(this).attr("class");


        var registration = $("#bus_registration").val()
        var comfort = $("#bus_comfort").val()
        var capacity = $("#bus_capacity").val()
        
        
        if(registration && comfort && capacity){ 

            $.post("phpscripts/MainAPIs.php",{
                "token":token,
                "action":page,
                "registration":registration.toUpperCase(),
                "comfort":comfort.toUpperCase(),
                "capacity":capacity

            },function(data,status){
            	
                
                if(status == "success"){
                    //$response['error'] = true; 
                    //$response['message'] = 'Invalid username or password';
                    var response =JSON.parse(data)

                    if(response["error"] == false){
                       
                       alert(response["message"])
                       $(":input").val('')

                      
                    }else{
                        alert(response["message"])
                       
                    } 
                                 
                }else{
                    alert("Please retry an error has occured")
                }

            })

           

        }else{
            alert("All fields must be filled")
        }
        

    });

}

});

 
