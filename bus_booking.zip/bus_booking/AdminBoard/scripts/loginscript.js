$(document).ready(function(){
    localStorage.setItem("token","")
     localStorage.setItem("user","")
    $("input[type=submit]").click(function(){
        //var text = $(this).attr("class");
        var username = $("#user_name").val()
        var password = $("#user_password").val()
        //store token
        
        
        if(username && password){ 
            $.post("phpscripts/login.php",{
                "login":"log action",
                "username":username,
                "password":password

            },function(data,status){
                
                if(status == "success"){
                    //$response['error'] = true; 
                    //$response['message'] = 'Invalid username or password';
                    var response =JSON.parse(data)

                    if(response["error"] == false){
                       var user_id = response["user"]["user_id"]
                       var user = response["user"]["username"]
                       localStorage.setItem("token",user_id)
                       localStorage.setItem("user",user)
                       $(location).attr("href","./index.html")
                    }else{
                        alert(response["message"])
                       
                    } 
                                 
                }else{
                    alert("Please retry an error has occured")
                }

            })

           

        }else{
            alert("Password or Email must be supplied")
        }
        
          

    });
});