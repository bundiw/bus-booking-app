$(document).ready(function(){
	var token = localStorage.getItem("token")

    
	if(token == ""){
		$(location).attr("href","./login.html")
		

	}else{
		$("#logout").click(function(){
			$(location).attr("href","./login.html")
			localStorage.setItem("user","")
			localStorage.setItem("token","")

		});
		

		$("a").click(function(){
	    //var text = $(this).attr("class");
		    $("a").removeAttr("class")
		    $(this).attr("class","active")
		    var page = $(this).attr("href");
		    page = page.replace("#","")
		    localStorage.setItem("page",page)
		    if(page == "home"){
		    	location.reload();
		    }else{
		    	$("#content").load("./"+page+".html");

		    }
	    
	  	});
		
	}
 
});