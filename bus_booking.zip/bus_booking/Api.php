<?php 

	require_once 'DbConnect.php';
	
	$response = array();
	
	if(isset($_GET['apicall'])){
		
		switch($_GET['apicall']){
			
			case 'signup':
				if(isTheseParametersAvailable(array('username','phone', 'email','password','gender'))){
					$username = $_POST['username']; 
					$phone = $_POST['phone']; 
					$email = $_POST['email']; 
					$password = md5($_POST['password']);
					$gender = $_POST['gender']; 
					
					$stmt = $conn->prepare("SELECT user_id FROM users WHERE phone = ? OR email = ?");
					$stmt->bind_param("ss", $phone, $email);
					$stmt->execute();
					$stmt->store_result();
					
					if($stmt->num_rows > 0){
						$response['error'] = true;
						$response['message'] = 'User with that email or phone number is already registered';
						$stmt->close();
					}else{
						$stmt = $conn->prepare("INSERT INTO users (username, phone, email, password, gender) VALUES (?, ?, ?, ?, ?)");
						$stmt->bind_param("sssss", $username, $phone, $email, $password, $gender);

						if($stmt->execute()){
							$stmt = $conn->prepare("SELECT user_id, username, phone, email, gender FROM users WHERE phone = ?"); 
							$stmt->bind_param("s",$phone);
							$stmt->execute();
							$stmt->bind_result($id, $username, $phone, $email, $gender);
							$stmt->fetch();
							
							$user = array(
								'user_id'=>$id, 
								'username'=>$username, 
								'phone'=>$phone, 
								'email'=>$email,
								'gender'=>$gender
							);
							
							$stmt->close();
							
							$response['error'] = false; 
							$response['message'] = 'User registered successfully'; 
							$response['user'] = $user; 
						}
					}
					
				}else{
					$response['error'] = true; 
					$response['message'] = 'Required parameters are not available'; 
				}
				
			break; 
			
			case 'login':
				
				if(isTheseParametersAvailable(array('email', 'password'))){
					
					$email = $_POST['email'];
					$password = md5($_POST['password']);  
					
					$stmt = $conn->prepare("SELECT user_id, username, phone, email, gender FROM users WHERE email = ? AND password = ?");
					$stmt->bind_param("ss",$email, $password);
					
					$stmt->execute();
					
					$stmt->store_result();
					
					if($stmt->num_rows > 0){
						
						$stmt->bind_result($id, $username, $phone, $email, $gender);
						$stmt->fetch();
						
						$user = array(
							'user_id'=>$id, 
							'username'=>$username,
							'phone'=>$phone, 
							'email'=>$email,
							'gender'=>$gender
						);
						
						$response['error'] = false; 
						$response['message'] = 'Login successfull'; 
						$response['user'] = $user; 
					}else{
						$response['error'] = true; 
						$response['message'] = 'Invalid username or password';
					}
				}
			break; 
			
			default: 
				$response['error'] = true; 
				$response['message'] = 'Invalid Operation Called';
		}
		
	}else{
		$response['error'] = true; 
		$response['message'] = 'Invalid API Call';
	}
	
	echo json_encode($response);
	
	function isTheseParametersAvailable($params){
		
		foreach($params as $param){
			if(!isset($_POST[$param])){
				return false; 
			}
		}
		return true; 
	}