<?php 

require_once 'DbConnect.php';
$response = array();
// $_POST["email"]="lilian@gmail.com";
// $_POST["phone"]="0712455418";
// $_POST["from"] ="mombasa";
// $_POST["destination"]="nairobi";
// $_POST["registration"] ="kcd";
// $_POST["comfort"]="vvip";
// $_POST["date"] ="2022-12-12";
// $_POST["time"] = "07:12";
// $_POST["amount"] =" 3000";
//  $_POST["transcode"]="AK47";
//  $_GET['book'] =0;
if (isset($_GET['book'])) {
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $from = $_POST["from"];
    $destination = $_POST["destination"];
    
    $registration = $_POST["registration"];
    $comfort = $_POST["comfort"];
    $date = $_POST["date"];
    $time = $_POST["time"];
    $amount = $_POST["amount"];
    $transcode = $_POST["transcode"];
    $stmt = $conn ->prepare("SELECT `bus_capacity` FROM `buses` WHERE `plate_registration`= ? ");
    $stmt->bind_param("s",$registration);

    $stmt->execute();
    $stmt->bind_result($capacity);
    $stmt->store_result();

    
    if ($stmt->num_rows > 0) {
       
        $stmt-> fetch(); 
        $stmt->close();
        
        $stmt = $conn->prepare("INSERT INTO `book_bus`(`user_email`, `user_phone`, `depart_from`, `destination`, `plate_registration`, `bus_comfort`, `capacity`, `book_date`, `book_time`, `ticket_amount`, `mpesa_code`) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssssssss",$email,$phone,$from,$destination,$registration,$comfort,$capacity,$date,$time,$amount,$transcode);
      
        if($stmt->execute()){
            $stmt->close();
            $response['error'] = false; 
            $response['message'] = 'Bus Book sucessfully'; 
           
        }else{
            $stmt->close();
            $response['error'] = true; 
            $response['message'] = $conn->error;
        }
        
    }else{
        $stmt->close();
        $response['error'] = true; 
        $response['message'] = 'Uknown bus CAPACITY';
    }


}else{
    $response['error'] = true; 
    $response['message'] = 'Invalid API Call';
}
echo json_encode($response);

