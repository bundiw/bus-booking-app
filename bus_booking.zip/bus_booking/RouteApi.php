<?php
require_once 'DbConnect.php';
	
$response = array();

// $_POST['from'] = "mombasa";
// $_POST['to'] ="nairobi";
// $_POST['comfort']="vvip";
// $_POST['day'] ="2021-11-12";
// $_POST['time'] ="07:12";
// $_POST['bus'] ="KCD";
// $_GET['routes'] = "ticket";
if (isset($_GET['routes']) ) {
	

	switch($_GET['routes']){
			
			case 'from':

				if(isTheseParametersAvailable(array())){
					$stmt = $conn->prepare("SELECT DISTINCT  `depart_from` FROM `routes` WHERE 1"); 
				    
				    $stmt->execute();
				    
				    $stmt->bind_result($from);
				    $res = $stmt->get_result();
				     if($res->num_rows > 0){
				     	while ($route = $res->fetch_assoc()){
				       
					       $routes[] = $route ;
					    }
					                
					    
					    $stmt->close();
					    
					    $response['error'] = false; 
					    $response['message'] = 'Routes fetched sucessfully'; 
					    $response['routes'] = $routes;

				     }else{
				     	$response['error'] = true; 
					    $response['message'] = 'Route Not Available'; 
					   

				     }
    

				}
				else{
					$response['error'] = true; 
					$response['message'] = 'Access Denied';
					
				}
			break;

			case 'to':
			    //$_POST['from']="mombasa";
				$from = $_POST['from'];

				if(isTheseParametersAvailable(array('from'))){
					$stmt = $conn->prepare("SELECT DISTINCT `destination` FROM `routes` WHERE `depart_from` = ?");
					$stmt-> bind_param("s",$from) ;
			    
				    $stmt->execute();
				    
				    $stmt->bind_result($to);
				    $res = $stmt->get_result();
				     if($res->num_rows > 0){
				     	while ($route = $res->fetch_assoc()){
				       
					       $routes[] = $route ;
					    }
					                
					    
					    $stmt->close();
					    
					    $response['error'] = false; 
					    $response['message'] = 'Routes fetched sucessfully'; 
					    $response['routes'] = $routes;

				     }else{
				     	$response['error'] = true; 
					    $response['message'] = 'Route Not Available'; 
					   

				     }
    

				}
				else{
					$response['error'] = true; 
					$response['message'] = 'Access Denied';
				}
			break;

			case 'comfort':
				if(isTheseParametersAvailable(array('from','to'))){

					//SELECT `route_id`, `plate_registration`, `depart_from`, `destination`, `bus_comfort`, `travel_date`, `travel_time`, `travel_cost` FROM `routes` WHERE 1
					$from = $_POST['from'];
					$to = $_POST['to'];

					$stmt = $conn->prepare("SELECT  DISTINCT `bus_comfort` FROM `routes` WHERE `depart_from` = ? AND `destination` = ?");
					$stmt-> bind_param("ss",$from,$to) ;
			    
				    $stmt->execute();
				    
				    $stmt->bind_result($comfort);
				    $res = $stmt->get_result();
				     if($res->num_rows > 0){
				     	while ($route = $res->fetch_assoc()){
				       
					       $routes[] = $route ;
					    }
					                
					    
					    $stmt->close();
					    
					    $response['error'] = false; 
					    $response['message'] = 'Routes fetched sucessfully'; 
					    $response['routes'] = $routes;

				     }else{
				     	$response['error'] = true; 
					    $response['message'] = 'Route Not Available'; 
					   

				     }

				}
				else{
					$response['error'] = true; 
					$response['message'] = 'Access Denied';
				}

			break;

			case 'day':
				if(isTheseParametersAvailable(array('from','to', 'comfort'))){

					//SELECT `route_id`, `plate_registration`, `depart_from`, `destination`, `bus_comfort`, `travel_date`, `travel_time`, `travel_cost` FROM `routes` WHERE 1
					$from = $_POST['from'];
					$to = $_POST['to'];
					$comfort = $_POST['comfort'];

					$stmt = $conn->prepare("SELECT DISTINCT `travel_date` FROM `routes` WHERE `depart_from` = ? AND `destination` = ? AND `bus_comfort`=? ");
					$stmt-> bind_param("sss",$from,$to,$comfort);
			    
				    $stmt->execute();
				    
				    $stmt->bind_result($day);
				    $res = $stmt->get_result();
				     if($res->num_rows > 0){
				     	while ($route = $res->fetch_assoc()){
				       
					       $routes[] = $route ;
					    }
					                
					    
					    $stmt->close();
					    
					    $response['error'] = false; 
					    $response['message'] = 'Routes fetched sucessfully'; 
					    $response['routes'] = $routes;

				     }else{
				     	$response['error'] = true; 
					    $response['message'] = 'Route Not Available'; 
					   

				     }

				}
				else{
					$response['error'] = true; 
					$response['message'] = 'Access Denied';
				}
			break;

			case 'time':
				if(isTheseParametersAvailable(array('from','to', 'comfort','day'))){
					//SELECT `route_id`, `plate_registration`, `depart_from`, `destination`, `bus_comfort`, `travel_date`, `travel_time`, `travel_cost` FROM `routes` WHERE 1
					$from = $_POST['from'];
					$to = $_POST['to'];
					$comfort = $_POST['comfort'];
					$day = $_POST['day'];

					$stmt = $conn->prepare("SELECT  `travel_time` FROM `routes` WHERE `depart_from` = ? AND `destination` = ? AND `bus_comfort`=? AND `travel_date` = ? ");
					$stmt-> bind_param("ssss",$from,$to,$comfort,$day);
			    
				    $stmt->execute();
				    
				    $stmt->bind_result($time);
				    $res = $stmt->get_result();
				     if($res->num_rows > 0){
				     	while ($route = $res->fetch_assoc()){
				       
					       $routes[] = $route ;
					    }
					                
					    
					    $stmt->close();
					    
					    $response['error'] = false; 
					    $response['message'] = 'Routes fetched sucessfully'; 
					    $response['routes'] = $routes;

				     }else{
				     	$response['error'] = true; 
					    $response['message'] = 'Route Not Available'; 
					   

				     }

				}
				else{
					$response['error'] = true; 
					$response['message'] = 'Access Denied';
				}
			break;

			case 'bus':
				if(isTheseParametersAvailable(array('from','to', 'comfort','day','time'))){

						//SELECT `route_id`, `plate_registration`, `depart_from`, `destination`, `bus_comfort`, `travel_date`, `travel_time`, `travel_cost` FROM `routes` WHERE 1
					$from = $_POST['from'];
					$to = $_POST['to'];
					$comfort = $_POST['comfort'];
					$day = $_POST['day'];
					$time = $_POST['time'];

					$stmt = $conn->prepare("SELECT  `plate_registration` FROM `routes` WHERE `depart_from` = ? AND `destination` = ? AND `bus_comfort`=? AND `travel_date` = ? AND `travel_time`=? ");
					$stmt-> bind_param("sssss",$from,$to,$comfort,$day,$time);
			    
				    $stmt->execute();
				    
				    $stmt->bind_result($bus);
				    $res = $stmt->get_result();
				     if($res->num_rows > 0){
				     	while ($route = $res->fetch_assoc()){
				       
					       $routes[] = $route ;
					    }
					                
					    
					    $stmt->close();
					    
					    $response['error'] = false; 
					    $response['message'] = 'Routes fetched sucessfully'; 
					    $response['routes'] = $routes;

				     }else{
				     	$response['error'] = true; 
					    $response['message'] = 'Route Not Available'; 
					   

				     }

				}
				else{
					$response['error'] = true; 
					$response['message'] = 'Access Denied';
				}
			break;

			case 'ticket':
				if(isTheseParametersAvailable(array('from','to', 'comfort','day','time','bus'))){
						//SELECT `route_id`, `plate_registration`, `depart_from`, `destination`, `bus_comfort`, `travel_date`, `travel_time`, `travel_cost` FROM `routes` WHERE 1
					$from = $_POST['from'];
					$to = $_POST['to'];
					$comfort = $_POST['comfort'];
					$day = $_POST['day'];
					$time = $_POST['time'];
					$bus =$_POST['bus'];

					$stmt = $conn->prepare("SELECT  `travel_cost` FROM `routes` WHERE `depart_from` = ? AND `destination` = ? AND `bus_comfort`=? AND `travel_date` = ? AND `travel_time`=? AND `plate_registration` = ? ");
					$stmt-> bind_param("ssssss",$from,$to,$comfort,$day,$time,$bus);
			    
				    $stmt->execute();
				    
				    $stmt->bind_result($ticket);
				    $res = $stmt->get_result();
				     if($res->num_rows > 0){
				     	while ($route = $res->fetch_assoc()){
				       
					       $routes[] = $route ;
					    }
					                
					    
					    $stmt->close();
					    
					    $response['error'] = false; 
					    $response['message'] = 'Routes fetched sucessfully'; 
					    $response['routes'] = $routes;

				     }else{
				     	$response['error'] = true; 
					    $response['message'] = 'Route Not Available'; 
					   

				     }

				}
				else{
					$response['error'] = true; 
					$response['message'] = 'Access Denied';
				}
			break;

			default:
				$response['error'] = true; 
				$response['message'] = 'Invalid Operation Called';
			break;
		}

    
}else{
		$response['error'] = true; 
		$response['message'] = 'Invalid API Call';
}
echo json_encode($response);

function isTheseParametersAvailable($params){
		
	foreach($params as $param){
		if(!isset($_POST[$param])){
			return false; 
		}
	}
	return true; 
}