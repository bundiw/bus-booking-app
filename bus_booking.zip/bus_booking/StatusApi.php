		
<?php
require_once 'DbConnect.php';
	
$response = array();
// $_POST['status']="past";
// $_POST['email']="cbundi1405@gmail.com";
if (isset($_POST['status']) ) {
$today = date('Y-m-d H:i');
$day = strval($today);
//$d ="2021-11-2614:51";


	if ($_POST['status'] == "active") {
		$email =$_POST["email"];
		$status = "PENDING";
		
		$stmt =$conn -> prepare("SELECT `book_id`, `user_email`, `user_phone`, `depart_from`, `destination`, `plate_registration`, `bus_comfort`, `book_date`, `book_time`, `ticket_amount`, `mpesa_code`, `book_status`, `ticket_no`, `admin_no` FROM `book_bus` WHERE `user_email`=? AND CONCAT(`book_date`,`book_time`) > ?");
		$stmt->bind_param("ss",$email,$day);
		$stmt->execute();
		
	    $res = $stmt->get_result();
	     if($res->num_rows > 0){
	     	while ($book = $res->fetch_assoc()){
	       
		       $books[] = $book ;
		    }
		                
		    
		    $stmt->close();
		    
		    $response['error'] = false; 
		    $response['message'] = 'Booking fetched successfully'; 
		    $response['books'] = $books;

	     }else{
	     	$response['error'] = true; 
		    $response['message'] = 'No book Available'; 
		   

	     }

		//SELECT `book_id`, `user_email`, `user_phone`, `depart_from`, `destination`, `capacity`, `plate_registration`, `bus_comfort`, `book_date`, `book_time`, `ticket_amount`, `mpesa_code`, `book_status`, `ticket_no`, `admin_no` FROM `book_bus` WHERE 1

	}else if($_POST['status'] == "cancel"){
		$bookid = $_POST['bookid'];
		$status ="CANCELLED";
		$email =$_POST["email"];
		$stmt = $conn->prepare("UPDATE `book_bus` SET `book_status`= ?  WHERE `book_id` =?");
		$stmt->bind_param("ss",$status,$bookid);
		if ($stmt->execute()) {

		    $stmt->close();
		 	$response['error'] = false; 
		    $response['message'] = 'Booking CANCELLED successfully'; 
		   

	     }else{
	     	$response['error'] = true; 
		    $response['message'] = 'Inform the ADMIN'; 
		   

	     }
		

	}
	else{
		$email =$_POST["email"];
		$stmt =$conn -> prepare("SELECT `book_id`, `user_email`, `user_phone`, `depart_from`, `destination`, `plate_registration`, `bus_comfort`, `book_date`, `book_time`, `ticket_amount`, `mpesa_code`, `book_status`, `ticket_no`, `admin_no` FROM `book_bus` WHERE `user_email`= ? AND CONCAT(`book_date`, `book_time`) < ?"); 
		$stmt ->bind_param("ss",$email,$day);
		$stmt->execute();

	    $res = $stmt->get_result();
	     if($res->num_rows > 0){
	     	while ($book = $res->fetch_assoc()){
	       
		       $books[] = $book ;
		    }
		                
		    
		    $stmt->close();
		    
		    $response['error'] = false; 
		    $response['message'] = 'Booking fetched successfully'; 
		    $response['books'] = $books;

	     }else{
	     	$response['error'] = true; 
		    $response['message'] = 'No book Available'; 
		   

	     }
	}
	
}else{
    $response['error'] = true; 
    $response['message'] = 'Invalid API Call';
}
echo json_encode($response);




	
