<?php
require_once 'DbConnect.php';
    
$response = array();

//SELECT `bill_id`, `user_phone`, `paid_amount`, `mpesa_code` FROM `transactions` WHERE `mpesa_code`= ?
// $_GET['mpesa']=0;
// $_POST["transcode"] ="AK47";
if(isset($_GET['mpesa'])){
    $status = $_GET['mpesa'];
    $transactions = $_POST["transcode"];
    $stmt = $conn->prepare("SELECT  `mpesa_code` FROM `transactions` WHERE `mpesa_code`= ? AND `status`=?");
    $stmt->bind_param("ss", $transactions,$status);
   
    $stmt->execute(); 
    $stmt->bind_result($mpesa_code);
    $stmt ->store_result();
    if($stmt->num_rows > 0){
        //UPDATE `transactions` SET `status`=? WHERE `mpesa_code`=?
        
        $stmt->fetch();
        
        $status = 1;
        $stmt->close();
        $stmt = $conn->prepare("UPDATE `transactions` SET `status`=? WHERE `mpesa_code`=?");
        $stmt->bind_param("ss",$status,$transactions);
        if ($stmt->execute() ==1) {
            $response['error'] = false; 
            $response['message'] = 'Code verification Success'; 
            $response['mpesa'] = $mpesa_code;
           
        }else{
            $response['error'] = true;
            $response['message'] ="Mpesa Code already Activate";

        }
        

    }else{
        $response['error'] = true;
        $response['message'] = 'Invalid Transaction Code, Retry or Contact Admin';
       
    }


}else{
    $response['error'] = true; 
    $response['message'] = 'Invalid API Call';
}
echo json_encode($response);
