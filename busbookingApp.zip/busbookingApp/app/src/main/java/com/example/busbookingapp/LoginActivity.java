package com.example.busbookingapp;
import android.content.Intent;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.android.volley.Request;

import com.android.volley.toolbox.StringRequest;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    EditText editTextUsername, editTextPassword;
    Button buttonLogin, buttonReset;
    ProgressBar progressBar;

    private String username;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //if user presses on login
        //calling the method login
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(view -> {
            //initialise the data
            initialiseData();
            userLogin();
        });

        buttonReset = findViewById(R.id.buttonReset);
        buttonReset.setOnClickListener(view -> {
            editTextPassword.setText(null);
            editTextUsername.setText(null);

        });

        //if user presses on not registered
        findViewById(R.id.textViewRegister).setOnClickListener(view -> {
            //open register screen
            finish();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        });
    }

    private void initialiseData(){
        //initialise the views
        progressBar = findViewById(R.id.progressBar);
        editTextUsername = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);


        //getting the values initialised on the view
        username = editTextUsername.getText().toString().trim();
        password = editTextPassword.getText().toString();

    }

    private void userLogin() {
        //validating inputs
        if (TextUtils.isEmpty(username)) {
            editTextUsername.setError("Please enter your Email");
            editTextUsername.requestFocus();

            return;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(username).matches()) {
            editTextUsername.setError("Enter a valid email");
            editTextUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            editTextPassword.setError("Please enter your password");
            editTextPassword.requestFocus();
            return;
        }


        progressBar.setVisibility(View.VISIBLE);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_LOGIN,
                response -> {


                    try {
                        //converting response to json object
                        JSONObject obj = new JSONObject(response);
                        //if no error in response
                        if (!obj.getBoolean("error")) {
                            //Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                            //getting the user from the response

                            JSONObject userJson = obj.getJSONObject("user");

                            //creating a new user object
                            User user = new User(
                                userJson.getInt("user_id"),
                                userJson.getString("username"),
                                userJson.getString("phone"),
                                userJson.getString("email"),
                                userJson.getString("gender")

                            );

                            //storing the user in shared preferences
                            progressBar.setVisibility(View.GONE);
                            SharedPrefManager.getInstance(getApplicationContext()).userLogin(user);
                            //starting the profile activity
                            finish();
                            startActivity(new Intent(getApplicationContext(), BookBusActivity.class));

                        } else {
                            Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        //Toast.makeText(getApplicationContext(),e,Toast.LENGTH_SHORT).show();

                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show())
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("email", username);
                params.put("password", password);
                return params;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


}