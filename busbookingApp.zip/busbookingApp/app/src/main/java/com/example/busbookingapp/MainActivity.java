package com.example.busbookingapp;

import android.content.Intent;

import android.os.Bundle;

import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;

import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername, editTextUserPhone, editTextEmail, editTextPassword, editTextConfirmPassword;
    private RadioGroup radioGroupGender;
    private Button buttonReset, buttonRegister;
    private ProgressBar progressBar;

    private String username,phone,email,password, cPassword, gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //if the user is already logged in we will directly start the profile activity
        if (SharedPrefManager.getInstance(this).isLoggedIn()) {
            finish();
            startActivity(new Intent(this, BookBusActivity.class));
            return;
        }



        initialiseData();

        buttonRegister= findViewById(R.id.buttonRegister);
        buttonRegister.setOnClickListener(view -> {
            //if user pressed on button register
            //here we will register the user to server
            initialiseData();
            registerUser();
        });
         //rest all the views values to null
        buttonReset= findViewById(R.id.buttonReset);
        buttonReset.setOnClickListener(view -> {
            //reset the all values to null
            editTextUsername.setText(null);
            editTextUserPhone.setText(null);
            editTextEmail.setText(null);
            editTextPassword.setText(null);
            editTextConfirmPassword.setText(null);

        });

        findViewById(R.id.textViewLogin).setOnClickListener(view -> {
            //if user pressed on login
            //we will open the login screen
            finish();
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
        });

    }

    private void initialiseData(){
        //initialise views
        progressBar = findViewById(R.id.progressBar);
        editTextUsername = findViewById(R.id.editTextPersonName);
        editTextUserPhone= findViewById(R.id.editTextPhone);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        radioGroupGender = findViewById(R.id.radioGender);

        //initial data on the views
        username = editTextUsername.getText().toString().trim();
        phone = editTextUserPhone.getText().toString().trim();
        email = editTextEmail.getText().toString().trim();
        password = editTextPassword.getText().toString().trim();
        cPassword = editTextConfirmPassword.getText().toString().trim();
        gender = ((RadioButton) findViewById(radioGroupGender.getCheckedRadioButtonId())).getText().toString();


    }

    private void registerUser() {
        //first we will do the validations

        if (TextUtils.isEmpty(username)) {
            editTextUsername.setError("Please enter your full name");
            editTextUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(phone)) {
            editTextUserPhone.setError("Please enter a phone number");
            editTextUserPhone.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(email)) {
            editTextEmail.setError("Please enter your email");
            editTextEmail.requestFocus();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Enter a valid email");
            editTextEmail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            editTextPassword.setError("Enter a password");
            editTextPassword.requestFocus();
            return;
        }

        if(!password.equals(cPassword)){
            editTextConfirmPassword.setError("The two passwords do not match");
            editTextConfirmPassword.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        //if it passes all the validations
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_REGISTER,
                response -> {


                    try {
                        //converting response to json object
                        JSONObject obj = new JSONObject(response);
                        //if no error in response
                        if (!obj.getBoolean("error")) {
                            Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                            //getting the user from the response
                            JSONObject userJson = obj.getJSONObject("user");

                            //creating a new user object
                            User user = new User(
                                    userJson.getInt("user_id"),
                                    userJson.getString("username"),
                                    userJson.getString("phone"),
                                    userJson.getString("email"),
                                    userJson.getString("gender")

                            );

                            //storing the user in shared preferences
                            SharedPrefManager.getInstance(getApplicationContext()).userLogin(user);
                            progressBar.setVisibility(View.GONE);
                            //starting the profile activity
                            finish();

                            startActivity(new Intent(getApplicationContext(), BookBusActivity.class));
                        } else {
                            Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {

                HashMap<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("phone",  phone);
                params.put("email",  email);
                params.put("password", password);
                params.put("gender", gender);

                return params;
            }
        };

        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }


}