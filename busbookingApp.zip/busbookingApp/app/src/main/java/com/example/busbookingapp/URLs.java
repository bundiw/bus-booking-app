package com.example.busbookingapp;

public class URLs {

    private static final String BASE_URL = "http://192.168.43.220/bus_booking";
    private static final String ROOT_URL = BASE_URL+"/Api.php?apicall=";
    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN = ROOT_URL + "login";
    public static final String URL_BOOK = BASE_URL + "/BookApi.php?book=0";

    public static final String URL_ROUTES = BASE_URL + "/RouteApi.php?routes=";
    public static final String URL_FROM = URL_ROUTES + "from";
    public static final String URL_TO = URL_ROUTES + "to";
    public static final String URL_COMFORT = URL_ROUTES + "comfort";
    public static final String URL_DAY = URL_ROUTES + "day";
    public static final String URL_TIME = URL_ROUTES + "time";
    public static final String URL_BUS = URL_ROUTES + "bus";
    public static final String URL_TICKET = URL_ROUTES + "ticket";

    public static final String URL_STATUS = BASE_URL + "/StatusApi.php";
    public static final String URL_MPESA = BASE_URL + "/transaction.php?mpesa=0";


}