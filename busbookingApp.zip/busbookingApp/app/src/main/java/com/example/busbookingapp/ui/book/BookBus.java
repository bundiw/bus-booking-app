package com.example.busbookingapp.ui.book;

public class BookBus {
    private String bookId,departureFrom,destination,comfort, Bus,time,day,ticketAmount,transCode;
    private static String bookState ="PENDING";

    public BookBus(String bookId, String departureFrom, String destination,
                   String comfort, String Bus, String time, String day, String ticketAmount, String transCode) {
        this.bookId = bookId;
        this.departureFrom = departureFrom;
        this.destination = destination;
        this.comfort = comfort;
        this.Bus = Bus;
        this.time = time;
        this.day = day;
        this.ticketAmount = ticketAmount;
        this.transCode = transCode;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getDepartureFrom() {
        return departureFrom;
    }

    public void setDepartureFrom(String departureFrom) {
        this.departureFrom = departureFrom;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getComfort() {
        return comfort;
    }

    public void setComfort(String comfort) {
        this.comfort = comfort;
    }

    public String getBus() {
        return Bus;
    }

    public void setBus(String bus) {
        this.Bus = bus;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTicketAmount() {
        return ticketAmount;
    }

    public void setTicketAmount(String ticketAmount) {
        this.ticketAmount = ticketAmount;
    }

    public String getTransCode() {
        return transCode;
    }

    public void setTransCode(String transCode) {
        this.transCode = transCode;
    }

    public static String getBookState() {
        return bookState;
    }

    public static void setBookState(String bookState) {
        BookBus.bookState = bookState;
    }
}
