package com.example.busbookingapp.ui.book;


import static android.graphics.Color.RED;
import static android.view.Gravity.*;

import android.content.Context;

import android.os.Bundle;
import android.view.Gravity;

import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;


import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;

import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;


import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Request.Method;

import com.android.volley.toolbox.StringRequest;
import com.example.busbookingapp.R;


import java.text.ParseException;


import java.text.SimpleDateFormat;
import java.time.LocalDate;

import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


import com.example.busbookingapp.SharedPrefManager;
import com.example.busbookingapp.URLs;
import com.example.busbookingapp.VolleySingleton;
import com.example.busbookingapp.databinding.FragmentBookBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class BookFragment extends Fragment {


    private FragmentBookBinding binding;
    private Spinner spDepartureFrom, spDestination, spComfort, spBus, spTime, spDate, spTicket;

    private String day;

    private String ticketFees;
    int newTicketAmount;
    private View view;
    private PopupWindow popupWindow;

    private ArrayList<String> optionsTo;
    private ArrayList<String> optionsComfort;
    private ArrayList<String> optionsDate;
    private ArrayList<String> optionsTime;
    private ArrayList<String> optionsBus;
    private ArrayList<String> optionsFees;
    HashMap<String,String> fromParam ;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
       // BookViewModel bookViewModel = new ViewModelProvider(this).get(BookViewModel.class);

        binding = FragmentBookBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        spDepartureFrom =binding.spinnerFrom;
        ArrayAdapter<String> spinnerArrayAdapterFrom;
        ArrayList<String> optionsFrom = new ArrayList<>();
        optionsFrom.add(0,"_SELECT_");
        populateSpinner(URLs.URL_FROM,fromParam,"depart_from", optionsFrom);

        spinnerArrayAdapterFrom = new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_spinner_item, optionsFrom);
        spinnerArrayAdapterFrom.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spDepartureFrom.setAdapter(spinnerArrayAdapterFrom);

        spDepartureFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               // paramFrom = spDepartureFrom.getSelectedItem().toString();

                fromParam = new HashMap<>();
                optionsTo = new ArrayList<>();
                optionsTo.add(0,"_SELECT_");
                fromParam.put("from",spDepartureFrom.getSelectedItem().toString());
                spDestination =binding.spinnerTo;
                ArrayAdapter<String> spinnerArrayAdapterTo;

                populateSpinner(URLs.URL_TO,fromParam, "destination",optionsTo);

                spinnerArrayAdapterTo = new ArrayAdapter<>(getActivity(),
                        android.R.layout.simple_spinner_item, optionsTo);
                spinnerArrayAdapterTo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spDestination.setAdapter(spinnerArrayAdapterTo);


                spDestination.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                        fromParam =new HashMap<>();
                        optionsComfort = new ArrayList<>();
                        optionsComfort.add(0,"_SELECT_");
                        fromParam.put("from",spDepartureFrom.getSelectedItem().toString());
                        fromParam.put("to",spDestination.getSelectedItem().toString());
                        spComfort = binding.spinnerComfort;

                        ArrayAdapter<String> spinnerArrayAdapterComf;
                        populateSpinner(URLs.URL_COMFORT,fromParam, "bus_comfort",optionsComfort);
                        spinnerArrayAdapterComf = new ArrayAdapter< >(getActivity(),
                                android.R.layout.simple_spinner_item, optionsComfort);
                        spinnerArrayAdapterComf.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                        spComfort.setAdapter(spinnerArrayAdapterComf);
                        spComfort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                fromParam =new HashMap<>();
                                optionsDate = new ArrayList<>();
                                optionsDate.add(0,"_SELECT_");
                                fromParam.put("from",spDepartureFrom.getSelectedItem().toString());
                                fromParam.put("to",spDestination.getSelectedItem().toString());
                                fromParam.put("comfort",spComfort.getSelectedItem().toString());
                                spDate = binding.spinnerDate;

                                ArrayAdapter<String> spinnerArrayAdapterDate;
                                populateSpinner(URLs.URL_DAY,fromParam, "travel_date",optionsDate);
                                spinnerArrayAdapterDate = new ArrayAdapter< >(getActivity(),
                                        android.R.layout.simple_spinner_item, optionsDate);
                                spinnerArrayAdapterDate.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                                spDate.setAdapter(spinnerArrayAdapterDate);
                                spDate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                        fromParam =new HashMap<>();
                                        optionsTime = new ArrayList<>();
                                        optionsTime.add(0,"_SELECT_");
                                        fromParam.put("from",spDepartureFrom.getSelectedItem().toString());
                                        fromParam.put("to",spDestination.getSelectedItem().toString());
                                        fromParam.put("comfort",spComfort.getSelectedItem().toString());
                                        fromParam.put("day",spDate.getSelectedItem().toString());
                                        spTime = binding.spinnerTime;


                                        ArrayAdapter<String> spinnerArrayAdapterTime;
                                        populateSpinner(URLs.URL_TIME,fromParam, "travel_time",optionsTime);
                                        spinnerArrayAdapterTime = new ArrayAdapter< >(getActivity(),
                                                android.R.layout.simple_spinner_item, optionsTime);
                                        spinnerArrayAdapterTime.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                                        spTime.setAdapter(spinnerArrayAdapterTime);
                                        spTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                            @Override
                                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                               // paramTime  =spTime.getSelectedItem().toString();
                                                fromParam =new HashMap<>();
                                                optionsBus = new ArrayList<>();
                                                optionsBus.add(0,"_SELECT_");
                                                fromParam.put("from",spDepartureFrom.getSelectedItem().toString());
                                                fromParam.put("to",spDestination.getSelectedItem().toString());
                                                fromParam.put("comfort",spComfort.getSelectedItem().toString());
                                                fromParam.put("day",spDate.getSelectedItem().toString());
                                                fromParam.put("time",spTime.getSelectedItem().toString());
                                                spBus = binding.spinnerBus;


                                                ArrayAdapter<String> spinnerArrayAdapterBus;
                                                populateSpinner(URLs.URL_BUS,fromParam, "plate_registration",optionsBus);
                                                spinnerArrayAdapterBus = new ArrayAdapter< >(getActivity(),
                                                        android.R.layout.simple_spinner_item, optionsBus);

                                                spinnerArrayAdapterBus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                                                spBus.setAdapter(spinnerArrayAdapterBus);

                                                spBus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                                    @Override
                                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                                        fromParam =new HashMap<>();
                                                        optionsFees = new ArrayList<>();
                                                        optionsFees.add(0,"_SELECT_");
                                                        fromParam.put("from",spDepartureFrom.getSelectedItem().toString());
                                                        fromParam.put("to",spDestination.getSelectedItem().toString());
                                                        fromParam.put("comfort",spComfort.getSelectedItem().toString());
                                                        fromParam.put("day",spDate.getSelectedItem().toString());
                                                        fromParam.put("time",spTime.getSelectedItem().toString());
                                                        fromParam.put("bus",spBus.getSelectedItem().toString());
                                                        spTicket = binding.spinnerTicket;
                                                        ArrayAdapter<String> spinnerArrayAdapterTicket;
                                                        populateSpinner(URLs.URL_TICKET,fromParam, "travel_cost",optionsFees);

                                                        spinnerArrayAdapterTicket = new ArrayAdapter< >(getActivity(),
                                                                android.R.layout.simple_spinner_item, optionsFees);

                                                        spinnerArrayAdapterTicket.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                                                        spTicket.setAdapter(spinnerArrayAdapterTicket);
                                                    }

                                                    @Override
                                                    public void onNothingSelected(AdapterView<?> parent) {

                                                    }
                                                });
                                            }

                                            @Override
                                            public void onNothingSelected(AdapterView<?> parent) {

                                            }
                                        });
                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });

                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        //work in progress
        binding.buttonBook.setOnClickListener(v -> initialiseData(binding));
        binding.buttonReset.setOnClickListener(v -> resetData(binding));


        return root;
    }

    public void populateSpinner(String url, HashMap<String, String> params ,String str,ArrayList<String> options){

        StringRequest stringRequest = new StringRequest(Method.POST, url,
                response -> {


                    try {


                        //converting response to json object
                        JSONObject obj = new JSONObject(response);
                        //if no error in response

                        if (!obj.getBoolean("error")) {

                            //System.out.println(response);

                        //{"error":false,"message":"Routes fetched sucessfully","routes":[{"depart_from":"mombasa"},{"depart_from":"mombasa"},{"depart_from":"mombasa"},{"depart_from":"mombasa"}]}
                            //getting the user from the response
                            JSONArray array = obj.getJSONArray("routes");

                            //creating a new user object
                            //Toast.makeText(getContext(), " Size: "+array.length(), Toast.LENGTH_SHORT).show();

                            for (int i=0; i< array.length(); i++){
                                JSONObject jsonObject = array.getJSONObject(i);
                                String name = jsonObject.getString(str);

                                options.add(name);
                            }


                           // System.out.println("I Bless the lord");

                        } else {
                            Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        //e.printStackTrace();
                        System.out.println("Error: "+e.getMessage());
                    }
                },
                error -> Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {

                return params;
            }
        };

        VolleySingleton.getInstance(getContext()).addToRequestQueue(stringRequest);



    }
    public void ComputeTicketAmount(){

        if (day.equals("_SELECT_") || ticketFees.equals("_SELECT_")){
            binding.textViewDay.setError("");
            binding.textViewDay.setText("Invalid Value");
            binding.textViewTicket.setText("Invalid Value");
            binding.textViewDay.setTextColor(RED);
            binding.textViewTicket.setTextColor(RED);
            popupWindow.dismiss();
            Toast.makeText(getContext(), "All Fields Must be filled", Toast.LENGTH_SHORT).show();


        }else{
            SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
            String today =simpleDateFormat.format(new Date());
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate d1 = LocalDate.parse(day,dateFormat);
            LocalDate d2 = LocalDate.parse(today,dateFormat);
            long diffDays = ChronoUnit.DAYS.between(d2, d1);
            int diff = (int) diffDays;

            //Toast.makeText(getContext(), "Diff: "+diffDays, Toast.LENGTH_SHORT).show();

            TextView textViewDiscount = view.findViewById(R.id.textDiscount);
            TextView textViewTicketAmount = view.findViewById(R.id.textAmount);


            newTicketAmount =calculatePrice(spTicket.getSelectedItem().toString(),diff,textViewDiscount,textViewTicketAmount);

        }

    }
    public void initialiseData(FragmentBookBinding binding){

        spDepartureFrom = binding.spinnerFrom;
        spDestination = binding.spinnerTo;
        spComfort = binding.spinnerComfort;
        spBus = binding.spinnerBus;
        spTime = binding.spinnerTime;
        spDate = binding.spinnerDate;
        spTicket = binding.spinnerTicket;


        //editTextDay = binding.editTextDay;
        if(isValid()){
            //proceed to book the bus with these valid data

            // inflate the layout of the popup window

            LayoutInflater inflater = (LayoutInflater) requireActivity().getSystemService (Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.book_payment, null);


            // create the popup window
            int width = LinearLayout.LayoutParams.MATCH_PARENT;
            int height = LinearLayout.LayoutParams.WRAP_CONTENT;

            popupWindow = new PopupWindow( view, width, height, true);

            // show the popup window
            // which view you pass in doesn't matter, it is only used for the window token
            popupWindow.showAtLocation(view, START, 0, 0);


                ComputeTicketAmount();
                EditText editTextTransCode = view.findViewById(R.id.editTextTransCode);
                view.findViewById(R.id.buttonReset).setOnClickListener(v -> editTextTransCode.setText(null));
                view.findViewById(R.id.buttonPay).setOnClickListener(v -> {
                    TextView tvAmount =view.findViewById(R.id.textAmount);
                    //g System.out.println(tvAmount.getText().toString()+" This  is save amout");
                    if (editTextTransCode.getText().toString().isEmpty()){
                        popupWindow.showAtLocation(view, START, 0, 0);
                        editTextTransCode.setError("Field cannot be empty");
                        editTextTransCode.requestFocus();
                    }else{
                        //Check if the transaction code exist in the database

                        String newAmount =String.valueOf(newTicketAmount);
                        VerifyCode(editTextTransCode,popupWindow,newAmount);


                    }


                });




        }
    }

public int calculatePrice(String money, int days,TextView tvDicount, TextView tvDiscountPrice){
        float fare = Float.parseFloat(money);
        int ticketAmount;

    if(days >= 60){
        //give 25% discount
        int discount = (int) (0.25f * fare);
        tvDicount.append(discount+".00");
        ticketAmount = (int)fare - discount;
        tvDiscountPrice.append(ticketAmount+".00");
    }else if (days >= 45){
        //give 20% discount
        int discount = (int) (0.20f * fare);
        tvDicount.append(discount+".00");
        ticketAmount = (int)fare - discount;
        tvDiscountPrice.append(ticketAmount+".00");
    }else if (days >= 30){
        //give 15% discount
        int discount = (int) (0.15f * fare);
        tvDicount.append(discount+".00");
        ticketAmount = (int)fare - discount;
        tvDiscountPrice.append(ticketAmount+".00");
    }else if(days >= 20){
        //give 10% discount
        int discount = (int) (0.10f * fare);
        tvDicount.append(discount+".00");
        ticketAmount = (int)fare - discount;
        tvDiscountPrice.append(ticketAmount+".00");
    }else if(days >= 10){
        //give 5% discount
        int discount = (int) (0.05f * fare);
        tvDicount.append(discount+".00");
        ticketAmount = (int)fare - discount;
        tvDiscountPrice.append(ticketAmount+".00");
    }else{
        //give 0% discount
        int discount = (int) (0.00f * fare);
        tvDicount.append(discount+".00");
        ticketAmount = (int)fare - discount;
        tvDiscountPrice.append(ticketAmount+".00");
    }

        return ticketAmount;
}

    public void VerifyCode( EditText editTextMCo,PopupWindow p,String amount){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_MPESA,
                response -> {


                    try {
                        //converting response to json object
                        JSONObject obj = new JSONObject(response);
                        //if no error in response
                      //  System.out.println("Proud "+response);
                        if (!obj.getBoolean("error")) {

                            //getting the user from the response

                            if (editTextMCo.getText().toString().trim().equalsIgnoreCase(obj.getString("mpesa"))){
                                //Toast.makeText(BookFragment.this.getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                                BookBus(editTextMCo,amount);
                                System.out.println("Never Give UP????"+ amount);


                                //new BookBus(bookId,departureFrom,destination,comfort,capacity,time,day,ticketAmount+"",transCode);
                                p.dismiss();

                            }else{
                                p.showAtLocation(view, START, 0, 0);
                                editTextMCo.setError("INVALID/USED MPESA CODE");
                                editTextMCo.requestFocus();


                            }



                        } else {
                            Toast.makeText(BookFragment.this.getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {

                HashMap<String, String> params = new HashMap<>();
                params.put("transcode",editTextMCo.getText().toString().trim() );


                return params;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

    }
    public void BookBus(EditText editTextCode, String feeAmount){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_BOOK,
                response -> {
                  //  System.out.println("Another one "+cost);

                    try {
                        //converting response to json object
                        JSONObject obj = new JSONObject(response);
                        //if no error in response
                        if (!obj.getBoolean("error")) {
                            Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {

                HashMap<String, String> params = new HashMap<>();

                params.put("email", SharedPrefManager.getInstance(getContext()).getUser().getEmail());
                params.put("phone",  SharedPrefManager.getInstance(getContext()).getUser().getPhone());
                params.put("from",  spDepartureFrom.getSelectedItem().toString());
                params.put("destination", spDestination.getSelectedItem().toString());

                params.put("registration", spBus.getSelectedItem().toString());
                params.put("comfort",  spComfort.getSelectedItem().toString());
                params.put("date",  spDate.getSelectedItem().toString());
                params.put("time", spTime.getSelectedItem().toString());
                params.put("amount", feeAmount);


                params.put("transcode", editTextCode.getText().toString().trim());

                return params;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

    }
    public void resetData(FragmentBookBinding binding){
      // binding.editTextDay.setText(null);
       binding.spinnerTicket.setSelection(0);
       binding.spinnerFrom.setSelection(0);
       binding.spinnerTo.setSelection(0);
       binding.spinnerComfort.setSelection(0);
       binding.spinnerBus.setSelection(0);
       binding.spinnerTime.setSelection(0);
       binding.spinnerDate.setSelection(0);

    }
    public boolean isValid(){
        boolean flag=true;
        String departureFrom = spDepartureFrom.getSelectedItem().toString().trim();
        String destination = spDestination.getSelectedItem().toString().trim();
        String comfort = spComfort.getSelectedItem().toString().trim();
        String capacity = spBus.getSelectedItem().toString().trim();
        String time = spTime.getSelectedItem().toString().trim();
        day=  spDate.getSelectedItem().toString().trim();
        ticketFees = spTicket.getSelectedItem().toString().trim();

        if(departureFrom.equals("__Select__")){

            Toast.makeText(getContext(),"Please Select the Place you are traveling from!",Toast.LENGTH_SHORT).show();
            flag = false;
        }
        if(destination.equals("__Select__")){

            Toast.makeText(getContext(),"Please Select the Place you are traveling!!",Toast.LENGTH_SHORT).show();
            flag = false;
        }
        if(comfort.equals("__Select__")){

            Toast.makeText(getContext(),"Please Select the Comfort status of the Bus!!",Toast.LENGTH_SHORT).show();
            flag = false;
        }
        if(capacity.equals("__Select__")){

            Toast.makeText(getContext(),"Please Select the Capacity of the Bus!!",Toast.LENGTH_SHORT).show();
            flag = false;
        }
        if(time.equals("__Select__")){

            Toast.makeText(getContext(),"Please Select the Preferred Departure Time!!",Toast.LENGTH_SHORT).show();
            flag = false;
        }

        if(ticketFees.equals("__Select__")){

            Toast.makeText(getContext(),"Please Select the Ticket Amount",Toast.LENGTH_SHORT).show();
            flag = false;
        }
        if(day.equals("__Select__")){
            binding.textViewDay.setError("");
            binding.textViewDay.setText("Outdated Date Value");
            binding.textViewDay.setTextColor(RED);
            Toast.makeText(getContext(),"Please Select Booking Day",Toast.LENGTH_SHORT).show();
            flag = false;
        }



        return flag;
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}