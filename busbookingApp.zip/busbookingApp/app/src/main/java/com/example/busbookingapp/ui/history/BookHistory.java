package com.example.busbookingapp.ui.history;

public class BookHistory {
    private String BookId, DepartureFrom, Destination, AmountPaid, BookYear, BookTime, BookStatus;

    public BookHistory(String bookId, String departureFrom, String destination, String amountPaid, String bookYear, String bookTime, String bookStatus) {
        BookId = bookId;
        DepartureFrom = departureFrom;
        Destination = destination;
        AmountPaid = amountPaid;
        BookYear = bookYear;
        BookTime = bookTime;
        BookStatus = bookStatus;
    }

    public String getBookId() {
        return BookId;
    }

    public void setBookId(String bookId) {
        BookId = bookId;
    }

    public String getDepartureFrom() {
        return DepartureFrom;
    }

    public void setDepartureFrom(String departureFrom) {
        DepartureFrom = departureFrom;
    }

    public String getDestination() {
        return Destination;
    }

    public void setDestination(String destination) {
        Destination = destination;
    }

    public String getAmountPaid() {
        return AmountPaid;
    }

    public void setAmountPaid(String amountPaid) {
        AmountPaid = amountPaid;
    }

    public String getBookYear() {
        return BookYear;
    }

    public void setBookYear(String bookYear) {
        BookYear = bookYear;
    }

    public String getBookTime() {
        return BookTime;
    }

    public void setBookTime(String bookTime) {
        BookTime = bookTime;
    }

    public String getBookStatus() {
        return BookStatus;
    }

    public void setBookStatus(String bookStatus) {
        BookStatus = bookStatus;
    }
}