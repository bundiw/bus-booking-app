package com.example.busbookingapp.ui.history;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.busbookingapp.R;
import com.example.busbookingapp.ui.status.BookStatus;
import com.example.busbookingapp.ui.status.StatusAdapter;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
    private List<BookHistory> historyList;
    public HistoryAdapter(List<BookHistory> historyList) {
        this.historyList =historyList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_history_model,parent, false);

        return new HistoryAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.textViewDepartureFrom.setText(String.format("From: %s", historyList.get(position).getDepartureFrom()));
        holder.textViewDestination.setText(String.format("To: %s", historyList.get(position).getDestination()));
        holder.textViewAmountPaid.setText(historyList.get(position).getAmountPaid());
        holder.textViewDayTime.setText(String.format("On: %s, %s hrs", historyList.get(position).getBookYear(), historyList.get(position).getBookTime()));
        holder.buttonStatus.setText(historyList.get(position).getBookStatus());
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        // private String DepartureFrom, Destination, AmountPaid, BookYear, BookTime, BookStatus;
        private final TextView textViewDepartureFrom, textViewDestination,textViewAmountPaid,
                textViewDayTime;
        private Button buttonDownload,buttonStatus, buttonCancel;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.textViewDepartureFrom = itemView.findViewById(R.id.textViewFrom) ;
            this.textViewDestination = itemView.findViewById(R.id.textViewTo);
            this.textViewAmountPaid = itemView.findViewById(R.id.textViewTicketAmount);
            this.textViewDayTime = itemView.findViewById(R.id.textViewDayTime);

            this.buttonStatus = itemView.findViewById(R.id.buttonStatus);

        }
    }
}
