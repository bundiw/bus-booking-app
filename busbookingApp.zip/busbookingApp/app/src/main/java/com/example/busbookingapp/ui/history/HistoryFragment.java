package com.example.busbookingapp.ui.history;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import androidx.annotation.NonNull;

import androidx.fragment.app.Fragment;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.example.busbookingapp.BookBusActivity;
import com.example.busbookingapp.SharedPrefManager;
import com.example.busbookingapp.URLs;
import com.example.busbookingapp.User;
import com.example.busbookingapp.VolleySingleton;
import com.example.busbookingapp.databinding.FragmentHistoryBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class HistoryFragment extends Fragment {

    private HistoryViewModel historyViewModel;
    private FragmentHistoryBinding binding;

    RecyclerView rvBookStatus;
    private List<BookHistory> historyList = new ArrayList<BookHistory>();
    HistoryAdapter adapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //historyViewModel =
          //      new ViewModelProvider(this).get(HistoryViewModel.class);

        binding = FragmentHistoryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        rvBookStatus = binding.rvBookHistory;

        setBookHistory();

        return root;
    }
    private void setBookHistory() {


        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_STATUS,
                response -> {


                    try {
                        //converting response to json object
                        JSONObject obj = new JSONObject(response);
                        //System.out.println("History "+response);
                        //if no error in response
                        if (!obj.getBoolean("error")) {
                            Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                            //getting the user from the response
                            JSONArray array = obj.getJSONArray("books");
                            int counter =0;
                            BookHistory items;
                            while (counter < array.length()){
                                JSONObject jsonObject = array.getJSONObject(counter);
                               // System.out.println(jsonObject.getString("destination"));

                                String bookid =jsonObject.getString("book_id");
                                String from =jsonObject.getString("depart_from");
                                String to =jsonObject.getString("destination");
                                String amount = "Ticket Fees: "+jsonObject.getString("ticket_amount")+".00";
                                String date = jsonObject.getString("book_date");
                                String time =jsonObject.getString("book_time");
                                String status =jsonObject.getString("book_status");
                                items =new BookHistory(
                                        bookid,
                                        from,
                                        to,
                                        amount,
                                        date,
                                        time,
                                        status
                                );
                                this.historyList.add(items);
                                counter++;
                            }

                            adapter = new HistoryAdapter(historyList);
                            RecyclerView.LayoutManager manager = new LinearLayoutManager(getContext());
                            rvBookStatus.setLayoutManager(manager);
                            rvBookStatus.setAdapter(adapter);

                        } else {
                            Toast.makeText(getContext(), obj.getString("message")+"fil", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {

                HashMap<String, String> params = new HashMap<>();
                params.put("status", "past");
                params.put("email",  SharedPrefManager.getInstance(getContext()).getUser().getEmail());

                return params;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}