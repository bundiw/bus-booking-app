package com.example.busbookingapp.ui.status;

public class BookStatus {
    private String bookId,DepartureFrom, Destination, AmountPaid, BookYear, BookTime, BookStatus;

    public BookStatus(String bookId, String departureFrom, String destination, String amountPaid, String bookYear, String bookTime, String bookStatus) {
        this.bookId = bookId;
        DepartureFrom = departureFrom;
        Destination = destination;
        AmountPaid = amountPaid;
        BookYear = bookYear;
        BookTime = bookTime;
        BookStatus = bookStatus;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getDepartureFrom() {
        return DepartureFrom;
    }

    public void setDepartureFrom(String departureFrom) {
        DepartureFrom = departureFrom;
    }

    public String getDestination() {
        return Destination;
    }

    public void setDestination(String destination) {
        Destination = destination;
    }

    public String getAmountPaid() {
        return AmountPaid;
    }

    public void setAmountPaid(String amountPaid) {
        AmountPaid = amountPaid;
    }

    public String getBookYear() {
        return BookYear;
    }

    public void setBookYear(String bookYear) {
        BookYear = bookYear;
    }

    public String getBookTime() {
        return BookTime;
    }

    public void setBookTime(String bookTime) {
        BookTime = bookTime;
    }

    public String getBookStatus() {
        return BookStatus;
    }

    public void setBookStatus(String bookStatus) {
        BookStatus = bookStatus;
    }
}
