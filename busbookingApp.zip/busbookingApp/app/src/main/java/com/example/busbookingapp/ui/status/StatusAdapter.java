package com.example.busbookingapp.ui.status;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.example.busbookingapp.BookBusActivity;
import com.example.busbookingapp.R;
import com.example.busbookingapp.SharedPrefManager;
import com.example.busbookingapp.URLs;
import com.example.busbookingapp.User;
import com.example.busbookingapp.VolleySingleton;
import com.example.busbookingapp.ui.book.BookFragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatusAdapter extends RecyclerView.Adapter<StatusAdapter.ViewHolder> {
    private List<BookStatus> statusList;
    public StatusAdapter(List<BookStatus> statusList) {
        this.statusList = statusList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_status_model,parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textViewDepartureFrom.setText(String.format("From: %s", statusList.get(position).getDepartureFrom()));
        holder.textViewDestination.setText(String.format("To: %s", statusList.get(position).getDestination()));
        holder.textViewAmountPaid.setText(String.format("Ticket Fees: ksh %s", statusList.get(position).getAmountPaid()));
        holder.textViewDayTime.setText(String.format("On: %s, %s hrs", statusList.get(position).getBookYear(), statusList.get(position).getBookTime()));

        holder.cancelBook(statusList.get(position).getAmountPaid(),statusList.get(position).getBookId());
        holder.downloadTicket();
        if(statusList.get(position).getBookStatus().equalsIgnoreCase("CANCELLED")){
            holder.buttonCancel.setEnabled(false);
            holder.buttonCancel.setActivated(false);
        }else{
            holder.buttonStatus.setText(statusList.get(position).getBookStatus());
        }


    }

    @Override
    public int getItemCount() {

        return statusList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        // private String DepartureFrom, Destination, AmountPaid, BookYear, BookTime, BookStatus;
        private final TextView textViewDepartureFrom, textViewDestination,textViewAmountPaid,
                textViewDayTime;

        private AlertDialog.Builder alertDialog;
        private Button buttonDownload,buttonStatus, buttonCancel;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.textViewDepartureFrom = itemView.findViewById(R.id.textViewFrom) ;
            this.textViewDestination = itemView.findViewById(R.id.textViewTo);
            this.textViewAmountPaid = itemView.findViewById(R.id.textViewTicketAmount);
            this.textViewDayTime = itemView.findViewById(R.id.textViewDayTime);

            this.buttonDownload = itemView.findViewById(R.id.buttonDownload);
            this.buttonStatus = itemView.findViewById(R.id.buttonStatus);
            this.buttonCancel = itemView.findViewById(R.id.buttonCancel);
        }



        public void downloadTicket(){
            buttonDownload.setOnClickListener(v -> {
                // initializing our variables.

                Bitmap bmp = null;
                Bitmap scaledBmp = null;
                if ( v!= null) {
                    bmp = BitmapFactory.decodeResource(v.getContext().getResources(), R.drawable.anotherimage);
                    Toast.makeText(v.getContext(), "Say It", Toast.LENGTH_SHORT).show();
                }
                try {
                    scaledBmp = Bitmap.createScaledBitmap(bmp, 140, 140, false);

                    PDFGenerator pdfGenerator = new PDFGenerator(v.getContext(), (Activity)v.getContext(), buttonDownload, bmp, scaledBmp);

                    pdfGenerator.generatePDF();
                }catch (Exception e){
                    e.printStackTrace();
                    //Toast.makeText(v.getContext(), "Hi Error", Toast.LENGTH_SHORT).show();
                }

            });

        }
        public void cancelBook(String amount,String bookid){
            buttonCancel.setOnClickListener(v -> {
                alertDialog = new AlertDialog.Builder(v.getContext());
                alertDialog.setTitle("Refundable amount is "+(Float.parseFloat(amount)*0.80)+". Do you wish to proceed?");

                alertDialog.setPositiveButton("Accept", (dialog, which) -> {
                    //cancel booking method goes here
                    //work in progress
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_STATUS,
                            response -> {


                                try {
                                    //converting response to json object
                                    JSONObject obj = new JSONObject(response);
                                    //if no error in response
                                    if (!obj.getBoolean("error")) {
                                        Toast.makeText(v.getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();

                                       } else {
                                        Toast.makeText(v.getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            },
                            error -> Toast.makeText(v.getContext(), error.getMessage(), Toast.LENGTH_SHORT).show()) {
                        @Override
                        protected Map<String, String> getParams() {

                            HashMap<String, String> params = new HashMap<>();
                            params.put("status", "cancel");
                            params.put("bookid",  bookid);


                            return params;
                        }
                    };

                    VolleySingleton.getInstance(v.getContext()).addToRequestQueue(stringRequest);
                    //Toast.makeText(v.getContext(), "You have successfully canceled the booking", Toast.LENGTH_SHORT).show();

                    dialog.dismiss();

                });
                alertDialog.setNegativeButton("Decline", (dialog, which) -> {
                    Toast.makeText(v.getContext(), "No Changes Made", Toast.LENGTH_SHORT).show();
                    dialog.cancel();
                });

                AlertDialog alert = alertDialog.create();
                alert.show();
                Button nButton = alert.getButton(DialogInterface.BUTTON_NEGATIVE);
                nButton.setBackgroundColor(Color.parseColor("#FFA500"));


                Button pButton = alert.getButton(DialogInterface.BUTTON_POSITIVE);
                pButton.setBackgroundColor(Color.parseColor("#FF0500"));
            });

        }


    }
}
