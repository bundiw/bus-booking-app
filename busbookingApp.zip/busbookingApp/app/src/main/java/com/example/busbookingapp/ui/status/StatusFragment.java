package com.example.busbookingapp.ui.status;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import androidx.annotation.NonNull;

import androidx.fragment.app.Fragment;


import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.example.busbookingapp.SharedPrefManager;
import com.example.busbookingapp.URLs;
import com.example.busbookingapp.VolleySingleton;
import com.example.busbookingapp.databinding.FragmentStatusBinding;
import com.example.busbookingapp.ui.history.BookHistory;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class StatusFragment extends Fragment {


    private FragmentStatusBinding binding;

    RecyclerView rvBookStatus;
    List<BookStatus> statusList = new ArrayList<>();
    StatusAdapter adapter;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
//        statusViewModel =
//                new ViewModelProvider(this).get(StatusViewModel.class);

        binding = FragmentStatusBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        rvBookStatus = binding.rvBookStatus;

        setBookStatus();

        return root;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PDFGenerator.PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {

                // after requesting permissions we are showing
                // users a toast message of permission granted.
                boolean writeStorage = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                boolean readStorage = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                if (writeStorage && readStorage) {
                    Toast.makeText(getContext(), "Permission Granted..", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Permission Denied.", Toast.LENGTH_SHORT).show();
                    //getContext.finish();
                }
            }
        }
    }

    private void setBookStatus() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_STATUS,
                response -> {


                    try {
                        //converting response to json object
                        JSONObject obj = new JSONObject(response);
                        //System.out.println("Status "+response);
                        //if no error in response
                        if (!obj.getBoolean("error")) {
                            Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                           // System.out.println("No matter may come my way");
                            //getting the user from the response
                            JSONArray array = obj.getJSONArray("books");
                            int counter =0;

                            while (counter < array.length()){
                                JSONObject jsonObject = array.getJSONObject(counter);
                                BookStatus status = new BookStatus(
                                        jsonObject.getString("book_id"),
                                        jsonObject.getString("depart_from"),
                                        jsonObject.getString("destination"),
                                        jsonObject.getString("ticket_amount"),
                                        jsonObject.getString("book_date"),
                                        jsonObject.getString("book_time"),
                                        jsonObject.getString("book_status"));
                                statusList.add(status);

                                counter++;
                            }

                            adapter = new StatusAdapter(statusList);
                            RecyclerView.LayoutManager manager = new LinearLayoutManager(getContext());
                            rvBookStatus.setLayoutManager(manager);
                            rvBookStatus.setAdapter(adapter);




                        } else {
                            Toast.makeText(getContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {

                HashMap<String, String> params = new HashMap<>();
                params.put("status", "active");
                params.put("email",  SharedPrefManager.getInstance(getContext()).getUser().getEmail());

                return params;
            }
        };
        VolleySingleton.getInstance(getActivity()).addToRequestQueue(stringRequest);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}